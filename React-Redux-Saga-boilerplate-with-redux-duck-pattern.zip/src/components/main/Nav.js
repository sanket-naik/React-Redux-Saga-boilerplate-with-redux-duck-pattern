import React from 'react'

export default function Nav() {
  return (
    <div>
      This is test Nav.js
    </div>
  )
}
