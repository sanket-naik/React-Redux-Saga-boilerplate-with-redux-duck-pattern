//PROD OR DEV
export const env = "dev"; 