export const urls={
    HOME:'/',
    TEST:'/Dummy'
  }